#!/ usr/bin/python3

import os, sys, pytest
import ansitron
from ansitron import dotatronenv, dotatron
from ansitron.dumper import *
from ansitron.bin import ansitron_builder

os.environ['MY_PACKAGE_ROOT'] = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
configvarstore= os.path.join(os.environ['MY_PACKAGE_ROOT'], 'config/varstore.dat')


@pytest.mark.usefixtures("path")
class Test_CLASS_Dotatronenv:


    @pytest.fixture(autouse=True)
    def _request_path(self, path):
        atronpath, ansdir, configpath = path
        self.atronpath = atronpath
        self.ansdir = ansdir
        self.configpath = configpath

    @pytest.fixture(autouse=True)
    def setup_method(self,path):
        if os.path.exists(os.path.join(self.atronpath,'.atronenv')):
            pass
        else:
            ansitron_builder._builddefaults_dotatronenv(path=self.atronpath)

  #  @pytest.fixture(autouse=True)
    def teardown_method(self,path):
        os.remove(os.path.join(self.atronpath,'.atronenv'))
        pass

#    @pytest.mark.dotatronenv
    def test_FUNC_find_dotatronenv(self):
        if dotatronenv.find_dotatronenv(path=self.atronpath):
            assert 1 == 1
        else:
            assert 1 == 0
    
#    @pytest.mark.dotatronenv
    def test_FUNC_load_dotatronenv(self):
        if dotatronenv.load_dotatronenv(dotatronenv.find_dotatronenv(path=self.atronpath)):
            assert 1 == 1
        else:
            assert 1 == 0

#    @pytest.mark.dotatronenv
    def test_FUNC_get_dotatronenv(self):
        assert dotatronenv.get_dotatronenv('ANSIBLE_PROJ_ROOT_DIR',path=self.atronpath) == 'None'
        assert dotatronenv.get_dotatronenv('PLAYBOOK_ABSOLUTE_DIR',path=self.atronpath) == 'None'
        assert dotatronenv.get_dotatronenv('JSON_FOLDER_NAME',path=self.atronpath) == 'json'
        assert dotatronenv.get_dotatronenv('YML_BKP_FOLDER_NAME',path=self.atronpath) == 'ymlbkp'
        assert dotatronenv.get_dotatronenv('FORMATTED_YML_FOLDER_NAME',path=self.atronpath) == 'formattedyml'

#    @pytest.fixture(autouse=True)
 #   def teardown_method(self,path):
  #      os.remove(os.path.join('/',self.atronpath,'.atronenv'))
   #     pass

