# test_param.py 

import pytest, os


@pytest.mark.usefixures("path")
class Test_rmpathfiles:


    @pytest.fixture(autouse=True)
    def _request_path(self, path):
        atronpath, ansdir, configpath = path
        self.atronpath = atronpath
        self.ansdir = ansdir
        self.configpath = configpath

    #@pytest.fixture(autouse=True)
    def test_tearfiles(self):
        if os.path.exists(os.path.join(self.atronpath,'.atronenv')):
            os.remove(os.path.join(self.atronpath,'.atronenv'))
        if os.path.exists(os.path.join(self.configpath,'ansitron.ini')):
            os.remove(os.path.join(self.configpath,'ansitron.ini'))

