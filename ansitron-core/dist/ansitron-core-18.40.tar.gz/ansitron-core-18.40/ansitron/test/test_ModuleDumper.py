#! /usr/bin/python3

import os, pytest, shutil, subprocess, json
import ansitron
from ansitron import dotatronenv, dotatron
from ansitron.dumper import *
from ansitron.bin import ansitron_builder
from datetime import date

os.environ['MY_PACKAGE_ROOT'] = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
configvarstore= os.path.join(os.environ['MY_PACKAGE_ROOT'], 'config/varstore.dat')

#@pytest.mark.parametrize("atronpath","ansdir","configpath", [("/tmp","/tmp","/tmp"), ("/var/lib/awx","/var/lib/awx","/tmp")])
@pytest.mark.usefixures("path")
class Test_CLASS_dumpdata_asfile:

    @pytest.fixture(autouse=True)
    def _request_path(self, path):
        atronpath, ansdir, configpath = path
        self.atronpath = atronpath
        self.ansdir = ansdir
        self.configpath = configpath
        self.pbookdir = os.path.join(ansdir,'tasks')

#    def test_sample(self, atronpath, ansdir, configpath):
        
 #       print(atronpath)
  #      print(ansdir)
   #     print(configpath)

    @pytest.fixture(autouse=True)
    def setup_method(self):

        if os.path.exists(os.path.join(self.atronpath,'.atronenv')):
            os.mkdir(self.pbookdir)
            dotatronenv.alter_dotatronenv('ANSIBLE_PROJ_ROOT_DIR',self.ansdir,path=self.atronpath)
            dotatronenv.alter_dotatronenv('PLAYBOOK_ABSOLUTE_DIR',self.pbookdir,path=self.atronpath)
            ansitron_builder._builddefaults_config(atronpath=self.atronpath, configpath=self.configpath)
            with open(os.path.join(dotatronenv.get_dotatronenv('PLAYBOOK_ABSOLUTE_DIR',path=self.atronpath),'test1.yml'), 'w') as f:
                f.write("- hosts: all\n")
                f.write("  tasks:\n")
                f.write("  - debug:\n")
                f.write("    var: inventory_hostname\n")
                f.close()
            with open(os.path.join(dotatronenv.get_dotatronenv('PLAYBOOK_ABSOLUTE_DIR',path=self.atronpath),'test2.yml'), 'w') as f:
                f.write("- hosts: win\n")
                f.write("  tasks:\n")
                f.write("  - debug:\n")
                f.write("    var: win_hostname\n")
                f.close()
        else:
            os.mkdir(self.pbookdir)
            ansitron_builder._builddefaults_dotatronenv(path=self.atronpath)
            dotatronenv.alter_dotatronenv('ANSIBLE_PROJ_ROOT_DIR',self.ansdir,path=self.atronpath)
            dotatronenv.alter_dotatronenv('PLAYBOOK_ABSOLUTE_DIR',self.pbookdir,path=self.atronpath)
            #shutil.copyfile(os.path.join(os.getenv('HOME'),'.atronenv'),os.path.join(os.getenv('HOME'),'bkp','.atronenv'))
            ansitron_builder._builddefaults_config(atronpath=self.atronpath, configpath=self.configpath)
            with open(os.path.join(dotatronenv.get_dotatronenv('PLAYBOOK_ABSOLUTE_DIR',path=self.atronpath),'test1.yml'), 'w') as f:
                f.write("- hosts: all\n")
                f.write("  tasks:\n")
                f.write("  - debug:\n")
                f.write("    var: inventory_hostname\n")
                f.close()
            with open(os.path.join(dotatronenv.get_dotatronenv('PLAYBOOK_ABSOLUTE_DIR',path=self.atronpath),'test2.yml'), 'w') as f:
                f.write("- hosts: win\n")
                f.write("  tasks:\n")
                f.write("  - debug:\n")
                f.write("    var: win_hostname\n")
                f.close()

    def teardown_method(self):

        shutil.rmtree(os.path.join(dotatronenv.get_dotatronenv('ANSIBLE_PROJ_ROOT_DIR',path=self.atronpath),'tasks'))
        if os.path.exists(os.path.join(dotatronenv.get_dotatronenv('ANSIBLE_PROJ_ROOT_DIR',path=self.atronpath),dotatronenv.get_dotatronenv('JSON_FOLDER_NAME',path=self.atronpath))):
            shutil.rmtree(os.path.join(dotatronenv.get_dotatronenv('ANSIBLE_PROJ_ROOT_DIR',path=self.atronpath),'json'))

    def test_FUNC_dump_ymlasjson(self):
        
        dumpdata_asfile.dump_ymlasjson(os.path.join(dotatronenv.get_dotatronenv('PLAYBOOK_ABSOLUTE_DIR',path=self.atronpath),'test1.yml'))
        with open(os.path.join(dotatronenv.get_dotatronenv('ANSIBLE_PROJ_ROOT_DIR',path=self.atronpath),dotatronenv.get_dotatronenv('JSON_FOLDER_NAME',path=self.atronpath),'test1.json'), 'r') as f:
            assert f.read() == """[
  {
    "hosts": "all",
    "tasks": [
      {
        "debug": null,
        "var": "inventory_hostname"
      }
    ]
  }
]"""

    def test_FUNC_dump_playbookasjson(self):
        
        dumpdata_asfile.dump_playbookasjson(dotatronenv.get_dotatronenv('PLAYBOOK_ABSOLUTE_DIR',path=self.atronpath))
        with open(os.path.join(dotatronenv.get_dotatronenv('ANSIBLE_PROJ_ROOT_DIR',path=self.atronpath),dotatronenv.get_dotatronenv('JSON_FOLDER_NAME',path=self.atronpath),'test1.json'), 'r') as f:
            assert f.read() == """[
  {
    "hosts": "all",
    "tasks": [
      {
        "debug": null,
        "var": "inventory_hostname"
      }
    ]
  }
]"""
        with open(os.path.join(dotatronenv.get_dotatronenv('ANSIBLE_PROJ_ROOT_DIR',path=self.atronpath),dotatronenv.get_dotatronenv('JSON_FOLDER_NAME',path=self.atronpath),'test2.json'), 'r') as f:
            assert f.read() == """[
  {
    "hosts": "win",
    "tasks": [
      {
        "debug": null,
        "var": "win_hostname"
      }
    ]
  }
]"""

    def test_FUNC_dump_envasjson(self):
        
        dumpdata_asfile.dump_envasjson('env')
        with open(os.path.join(dotatronenv.get_dotatronenv('ANSIBLE_PROJ_ROOT_DIR',path=self.atronpath),dotatronenv.get_dotatronenv('JSON_FOLDER_NAME',path=self.atronpath),'envbase.json'), 'w') as fbase:
            shellenv=json.dumps(dict(os.environ))
            fbase.write(shellenv+"\n")
        fbase = open(os.path.join(dotatronenv.get_dotatronenv('ANSIBLE_PROJ_ROOT_DIR',path=self.atronpath),dotatronenv.get_dotatronenv('JSON_FOLDER_NAME',path=self.atronpath),'envbase.json'))
        f = open(os.path.join(dotatronenv.get_dotatronenv('ANSIBLE_PROJ_ROOT_DIR',path=self.atronpath),dotatronenv.get_dotatronenv('JSON_FOLDER_NAME',path=self.atronpath),'env.json'))
        if ansitron.filehandlers._md5sumcompare(os.path.join(dotatronenv.get_dotatronenv('ANSIBLE_PROJ_ROOT_DIR',path=self.atronpath),dotatronenv.get_dotatronenv('JSON_FOLDER_NAME',path=self.atronpath),'envbase.json'),os.path.join(dotatronenv.get_dotatronenv('ANSIBLE_PROJ_ROOT_DIR',path=self.atronpath),dotatronenv.get_dotatronenv('JSON_FOLDER_NAME',path=self.atronpath),'env.json')):
            assert 1 == 1
        else:
            assert 1 == 0


    def test_FUNC_dump_playbookasformatdyml(self):
        
        dumpdata_asfile.dump_playbookasformatdyml(dotatronenv.get_dotatronenv('PLAYBOOK_ABSOLUTE_DIR',path=self.atronpath))
        if os.path.exists(os.path.join(dotatronenv.get_dotatronenv('PLAYBOOK_ABSOLUTE_DIR',path=self.atronpath),dotatronenv.get_dotatronenv('FORMATTED_YML_FOLDER_NAME',path=self.atronpath),'test1.yml')):
            assert 1 == 1
            pass
        else:
            assert 1 == 0
        with open(os.path.join(dotatronenv.get_dotatronenv('PLAYBOOK_ABSOLUTE_DIR',path=self.atronpath),dotatronenv.get_dotatronenv('FORMATTED_YML_FOLDER_NAME',path=self.atronpath),'test1.yml'), 'r') as f:
            assert f.read() == """---
- hosts: all
  tasks:
  - debug:
    var: inventory_hostname
"""
        with open(os.path.join(dotatronenv.get_dotatronenv('PLAYBOOK_ABSOLUTE_DIR',path=self.atronpath),dotatronenv.get_dotatronenv('FORMATTED_YML_FOLDER_NAME',path=self.atronpath),'test2.yml'), 'r') as f:
            assert f.read() == """---
- hosts: win
  tasks:
  - debug:
    var: win_hostname
"""
