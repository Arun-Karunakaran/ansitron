# conftest.py
import pytest

def pytest_addoption(parser):
    parser.addoption("--atronpath", action="store", help="test path for .atronenv")
    parser.addoption("--ansdir", action="store", help="test path for ANSIBLE_PROJ_ROOT_DIR")
    parser.addoption("--configpath", action="store", help="test path for CONFIG FILE")
    parser.addoption("--test-only", action="store_true", help="only run tests in dirs starting with test*")

#def pytest_config(config):
 #   test_only = config.getoption('--test-only')
  #  if test_only:
   #     config.args = [p for p in pathlib.Path().rglob('test*') if p.is_dir()]


@pytest.fixture()
def path(request):
    atronpath = request.config.getoption("--atronpath")
    ansdir = request.config.getoption("--ansdir")
    configpath = request.config.getoption("--configpath")
    return atronpath, ansdir, configpath


