#! /usr/bin/python3

import os, pytest, shutil
import ansitron
from ansitron import dotatronenv, dotatron
from ansitron.dumper import *
from ansitron.bin import ansitron_builder
from datetime import date

os.environ['MY_PACKAGE_ROOT'] = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
configvarstore= os.path.join(os.environ['MY_PACKAGE_ROOT'], 'config/varstore.dat')

def get_versionid():
    with open(configvarstore,'r') as f:
        l = [3]
        for position, line in enumerate(f):
            if position in l:
                versionid = line.lstrip("version=").rstrip("\n")
        return versionid

@pytest.mark.noparams
class Test_PACKAGE_init:


    def test_ProductName(self):
        assert ansitron.__name__ == "ansitron-standalone"

    def test_ProductVersion(self):
        assert ansitron.__version__ == get_versionid()

    def test_ProductAuthorName(self):
        assert ansitron.__author__ == "Arun Karunakaran"

    def test_CopyrightContnet(self):
        assert ansitron.__copyright__ == "Copyright 2020 ArunKarunakaran <akarunakaran.ind@gmail.com>"
    
    def test_ProductReleaseDate(self):
        assert ansitron.__date__ == date.today().strftime("%d-%m-%Y")
    
    def test_AuthorEmail(self):
        assert ansitron.__email__ == "akarunakaran.ind@gmail.com"

    def test_StatusOfRelease_(self):
        assert ansitron.__status__ == "Alpha-Release"

    def test_ReleaseInfo(self):
        assert ansitron.__releaseinfo__ == "Initial Release for ansitron-standalone. Description: This product is used for managing the ansible projects more effectively."
